<?php $__env->startSection('content'); ?>
<div class="container">      
    <div class="row justify-content-center">
        <div class="col-md-8">
            <app></app>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('custom_js'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/lara_app_5.8/resources/views/spa.blade.php ENDPATH**/ ?>